export default function Logs(){
    return (
        <main>
            <div>
                This  is the logs section 
            </div>
        </main>
    );
}