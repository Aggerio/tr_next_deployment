export default function Writing(){
    return (
        <div>
            Hello this is the writings page
        </div>
    );
}