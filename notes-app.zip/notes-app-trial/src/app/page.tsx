import Image from "next/image";
import styles from "./page.module.css";
import Header from "./_components/Header/header";

export default function Home() {
  return (
    <div>
      <Header />
    </div>
  );
}
