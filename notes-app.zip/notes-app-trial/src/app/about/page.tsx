export default function About(){
    return (
        <main>
            <div>
                This is the about page
            </div>
        </main>
    );
}