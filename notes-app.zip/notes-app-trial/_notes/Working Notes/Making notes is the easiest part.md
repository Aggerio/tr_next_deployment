---
title: Making notes is the easiest part
source: "[[BOOK- How to Take Smart Notes]]"
type: notes
created-date: 2024-02-05
updated-date: 2024-02-21
collection: notes
feed-show: false
tags:
  - notemaking
  - knowledge
---

It's easy to make notes.And there are many easier ways to make notes — like Copy-pasting or Quoting.What we miss while doing that is the intention of note-taking.

Use note-taking to develop ideas, arguments, and discussions, not to *collect* ideas.

---
### Source
- [[BOOK- How to Take Smart Notes]]
- [Evergreen Notes by Andy Matuschak](https://notes.andymatuschak.org/z4SDCZQeRo4xFEQ8H4qrSqd68ucpgE6LU155C) 